﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto3
{
    /* Se ingresa por teclado un número positivo de uno o dos dígitos (1..99)
     * mostrar un mensaje indicando si el número tiene uno o dos dígitos.
     * (Tener en cuenta que condición debe cumplirse para tener dos dígitos, un número entero)
+*/
    internal class Program
    {
        static void Main(string[] args)
        {

            Console.Write("Ingrese un número: ");
            int numero = int.Parse(Console.ReadLine());

            if (numero >= 1 && numero <= 9)
            {
                Console.WriteLine("el numero tiene un dígito");
            }
            else if (numero >= 10 && numero <= 99)
            {
                Console.WriteLine("el numero tiene dos dígitos");
            }
            else
            {
                Console.WriteLine("Número fuera de rango");

                
            }
            Console.ReadKey();
        }
    }
}
