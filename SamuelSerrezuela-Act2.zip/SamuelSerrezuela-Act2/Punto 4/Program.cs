﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto4
{
    /*Se cargan por teclado tres números distintos. Mostrar por pantalla el mayor de ellos.
Datos a tener en cuenta para la entrega:
+*/
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.Write("ingrese el primer número: ");
            int n1 = int.Parse(Console.ReadLine());

            Console.Write("ingrese el segundo número: ");
            int n2 = int.Parse(Console.ReadLine());

            Console.Write("ingrese el tercer número: ");
            int n3 = int.Parse(Console.ReadLine());

            if (n1 > n2 && n1 > n3)
            {
                Console.WriteLine("el mayor es: " + n1);
            }
            else if (n2 > n3)
            {
                Console.WriteLine("el mayor es: " + n2);
            }
            else
            {
                Console.WriteLine("el mayor es: " + n3);
            }
            Console.ReadKey();
        }
    }
}
