﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace punto2
{
    /*Se ingresan seis notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje "Promocionado"
+*/
    internal class Program
    {
        static void Main(string[] args)
        {
            int mat1, mat2, mat3, mat4, mat5, mat6, promedio;
            string linea;

            Console.Write("ingresa el valor de la 1ra materia: ");
            linea = Console.ReadLine();
            mat1 = int.Parse(linea);

            Console.Write("ingresa el valor de la 2da materia: ");
            linea = Console.ReadLine();
            mat2 = int.Parse(linea);

            Console.Write("ingresa el valor de la 3ra materia: ");
            linea = Console.ReadLine();
            mat3 = int.Parse(linea);

            Console.Write("ingresa el valor de la 4ra materia: ");
            linea = Console.ReadLine();
            mat4 = int.Parse(linea);

            Console.Write("ingresa el valor de la 5ta materia: ");
            linea = Console.ReadLine();
            mat5 = int.Parse(linea);

            Console.Write("ingresa el valor de la 6ta materia: ");
            linea = Console.ReadLine();
            mat6 = int.Parse(linea);

            promedio = (mat1 + mat2 + mat3 + mat4 + mat5 + mat6) / 6;

            if (promedio >= 7)
            {
                Console.WriteLine("el promedio es : ");
                Console.WriteLine(promedio);
                Console.WriteLine("promocionado");
            }
            Console.ReadKey();




        }



    }
}

