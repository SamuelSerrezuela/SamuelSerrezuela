﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto1
{

    /*Realizar un programa que lea por teclado dos números
     , si el primero es mayor al segundo informar su suma y diferencia
     , en caso contrario informar el producto y la división del primero respecto al segundo.    
*/
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, suma, resta, producto, division;
            string linea;

            Console.Write("ingresa el 1er numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingresa el 2do numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            if (num1 > num2)
            {
                suma = num1 + num2;
                resta = num1 - num2;
                Console.WriteLine("La suma es: " + suma);
                Console.WriteLine("La diferencia es: " + resta);
            }
            else
            {
                producto = num1 * num2;
                Console.WriteLine("El producto es: " + producto);

                if (num2 != 0)
                {
                    division = num1 / num2;
                    Console.WriteLine("La división es: " + division);
                }
                else
                {
                    Console.WriteLine("No se puede dividir por cero.");
                }
            }
            Console.ReadKey();






        }
    }
}
