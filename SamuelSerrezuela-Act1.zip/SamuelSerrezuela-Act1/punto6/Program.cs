﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese su peso en kg : ");
            int peso = int.Parse(Console.ReadLine());

            Console.Write("Ingrese su altura en metros : ");
            int altura = int.Parse(Console.ReadLine());

    
            int imc = peso / (altura * altura);

            Console.WriteLine("Su IMC aproximado es: " + imc);
        }
    }
}
