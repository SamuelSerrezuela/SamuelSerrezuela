﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace punto5
{
    internal class Program
    {
        /* Realizar la carga del radio de un círculo, mostrar por pantalla la circunferencia y
          el área del mismo (La circunferencia se calcula multiplicando el doble del radio por π (pi),
          y el área se calcula multiplicando π por el cuadrado del radio).*/
        static void Main(string[] args)
        {
            Console.Write("Ingrese el radio (número entero): ");
            int radio = int.Parse(Console.ReadLine());

            int circunferencia = (int)(2 * Math.PI * radio);

            int area = (int)(Math.PI * Math.Pow(radio, 2));

            Console.WriteLine("Circunferencia aproximada: " + circunferencia);
            Console.WriteLine("Área aproximada: " + area);
            Console.ReadKey();
        }
        
    }
    }

