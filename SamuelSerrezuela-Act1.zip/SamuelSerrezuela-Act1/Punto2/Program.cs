﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto2
{
    internal class Program
    {
        /*Escribir un programa en el cual se ingresen cuatro números,
        calcular e informar la suma de los dos primeros y
        el producto del tercero y el cuarto.*/
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, suma, producto;
            string linea;

            Console.Write("ingresa el 1er numero: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);

            Console.Write("ingresa el 2er numero: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);

            suma = num1 + num2;

            Console.Write("La suma de ambos numeros es: ");
            Console.WriteLine(suma);

            Console.Write("ingresa el 3er numero: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);

            Console.Write("ingresa el 4er numero: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            producto = num3 * num4;

            Console.Write("EL producto de ambos numeros es: ");
                Console.WriteLine(producto);
            Console.ReadKey();
           




        }
    }
}
