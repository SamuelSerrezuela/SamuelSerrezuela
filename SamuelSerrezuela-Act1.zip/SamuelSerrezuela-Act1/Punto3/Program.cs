﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Punto3
{
    /* Realizar un programa que lea cuatro valores numéricos e informar su suma y promedio.*/
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1, num2, num3, num4, suma, promedio;

            string linea;

            Console.WriteLine("Calcula la suma y promedio de 4 valores");

            Console.Write("ingresa el 1er valor: ");
            linea = Console.ReadLine();
            num1 = int.Parse(linea);
            Console.Write("ingresa el 2do valor: ");
            linea = Console.ReadLine();
            num2 = int.Parse(linea);
            Console.Write("ingresa el 3er valor: ");
            linea = Console.ReadLine();
            num3 = int.Parse(linea);
            Console.Write("ingresa el 4er valor: ");
            linea = Console.ReadLine();
            num4 = int.Parse(linea);

            suma = num1 + num2 + num3 + num4;
            promedio = suma % 4;

            Console.Write("EL producto de ambos numeros es: ");
            Console.WriteLine(linea);
            Console.ReadKey();


        }
    }
}

